# include <stdio.h>
# include <stdlib.h>

typedef struct Stack {
	int num;
	struct Stack *p_enext;
	struct Stack *p_mnext;
} NODE;

int push(int InputN, NODE *PEH, NODE *PMH){
	NODE *PUSH_NODE;

	PUSH_NODE = (NODE *)malloc(sizeof(NODE));

	PUSH_NODE->num = InputN;
	if (PEH->p_enext == NULL){
		PUSH_NODE->p_mnext = PMH->p_mnext;
		PMH->p_mnext = PUSH_NODE;
	}
	else if (PUSH_NODE->num < (PMH->p_mnext)->num){
		PUSH_NODE->p_mnext = PMH->p_mnext;
		PMH->p_mnext = PUSH_NODE;
	}
	PUSH_NODE->p_enext = PEH->p_enext;
	PEH->p_enext = PUSH_NODE;

	return PUSH_NODE->num;
}

int pop(NODE *PEH, NODE *PMH){
	NODE *POP_NODE = PEH->p_enext;

	if (POP_NODE == PMH->p_mnext){
		PMH->p_mnext = POP_NODE->p_mnext;
	}
	PEH->p_enext = POP_NODE->p_enext;

	free(POP_NODE);
	
	return POP_NODE->num;
}

int findMin(NODE *PMH){
	return (PMH->p_mnext)->num;
}

void pushMillion(NODE *PEH, NODE *PMH){
	int i, InputN;

	for (i = 0 ; i < 1000000 ; i++){
		InputN = (rand() % 9000) + 1000;
		push(InputN, PEH, PMH);
	}
}

void popMillion(NODE *PEH, NODE *PMH){
	int i;

	for (i = 0 ; i < 1000000 ; i++){
		pop(PEH, PMH);
	}
}

void DeleteAll(NODE *PEH, NODE *PMH){
	NODE *POP_NODE;

	while (PEH->p_enext != NULL){
		POP_NODE = PEH->p_enext;
		if (POP_NODE == PMH->p_mnext){
			PMH->p_mnext = POP_NODE->p_mnext;
		}
		PEH->p_enext = POP_NODE->p_enext;

		free(POP_NODE);
	}
}

int main(){
	char order;
	int N = 0, InputN, PUSH_N, POP_N, Min;

	NODE *PEH, *PMH;

	PEH = (NODE *)malloc(sizeof(NODE));
	PMH = (NODE *)malloc(sizeof(NODE));

	PEH->p_enext = NULL;
	PEH->p_mnext = NULL;

	PMH->p_enext = NULL;
	PMH->p_mnext = NULL;

	do {
		scanf("%c", &order);
		switch (order){
		case 'p' :
			scanf("%d", &InputN);
			PUSH_N = push(InputN, PEH, PMH);
			N++;
			printf("push %d (%d), cpu time = %lf\n", PUSH_N, N, );
			break;
		case 'o' :
			if (N == 0){
				printf("ERROR!!!\n");
			}
			else {
				POP_N = pop(PEH, PMH);
				printf("pop %d (%d), cpu time = %lf\n", POP_N, N, );
				N--;
			}
			break;
		case 'f' :
			Min = findMin(PMH);
			printf("min %d (%d), cpu time = %lf\n", Min, N, );
			break;
		case 'P' :
			pushMillion(PEH, PMH);
			N += 1000000;
			break;
		case 'O' :
			if (N < 1000000){
				printf("ERROR!!!\n");
			}
			else {
				popMillion(PEH, PMH);
				N -= 1000000;
			}
			break;
		}
	} while (order != 'q');

	DeleteAll(PEH, PMH);

	return 0;
}